//  Formularios
const formLogin = document.querySelector("#formLogin");
const formContentChat = document.querySelector(".body-chat");
const formShowUsers = document.querySelector("#formShowUsers");
const formChatGrupal = document.querySelector("#formChatGrupal");




formLogin.style.display = "none";
formContentChat.style.display = "flex";
formShowUsers.style.display = "block";
formChatGrupal.style.display = "block";