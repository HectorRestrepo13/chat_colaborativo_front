const socket = io('http://localhost:3000'); // Asegúrate de que la URL sea la correcta

const form = document.getElementById('form');
const input = document.getElementById('input');
const messages = document.getElementById('messages');

let grupoEscogido = "";

// Unirse a una sala
function func_selecionarSala(nombreGrupo) {
    grupoEscogido = nombreGrupo;
    socket.emit('join room', nombreGrupo);
}

form.addEventListener('submit', (e) => {
    e.preventDefault();

    if (input.value && grupoEscogido) {  // Asegúrate de que haya un grupo seleccionado
        socket.emit('send message', grupoEscogido, input.value);
        input.value = '';  // Limpiar el campo de entrada
    }
});

// Este evento lo que hace es recibir los mensajes enviados desde el servidor
socket.on('message', (msg) => {
    const item = document.createElement('li');
    item.textContent = msg;
    messages.appendChild(item);
});

// Salir de la sala
document.getElementById('leaveRoomButton').addEventListener('click', () => {
    if (grupoEscogido) {
        socket.emit('leave room', grupoEscogido);
    } else {
        console.log("No hay sala seleccionada para abandonar.");
    }
});



